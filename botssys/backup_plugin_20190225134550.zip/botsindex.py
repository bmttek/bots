# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import datetime
version = '3.2.0'
plugins = [
{u'plugintype': u'channel', 'apop': False, 'archivepath': u'/var/bots/archive/ch-in-brodart', 'askmdn': u'', 'certfile': u'', 'charset': u'us-ascii', 'desc': u'', 'filename': u'', 'ftpaccount': u'', 'ftpactive': False, 'ftpbinary': False, 'host': u'', 'idchannel': u'ch-in-brodart', 'inorout': u'in', 'keyfile': u'', 'lockname': u'', 'mdnchannel': u'', 'parameters': u'', 'path': u'/var/bots/channel/ch-in-brodart', 'port': 0L, 'remove': False, 'rsrv1': u'', 'rsrv2': None, 'rsrv3': 365L, 'secret': u'', 'sendmdn': u'', 'starttls': False, 'syslock': False, 'testpath': u'', 'type': u'file', 'username': u''},
]
